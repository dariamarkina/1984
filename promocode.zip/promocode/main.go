package main

import (
	"flag"
	"fmt"
	"math/rand"
	"net/http"
	"time"
)

const listen = ":3030"

var letterRunes = []rune("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")

var errorFlag int

func init() {
	const (
		usage = "the variety of gopher"
	)
	flag.IntVar(&errorFlag, "error", 0, "error = 0 - no error return service\nerror = 1 - error ym gen\nerror = 2 - error ym get\nerror = 3 - generate 0 promocodes")
}

func randStr(n int) string {
	b := make([]rune, n)
	for i := range b {
		b[i] = letterRunes[rand.Intn(len(letterRunes))]
	}
	return string(b)
}

func genCode() string {
	return "FAKE-" + randStr(4) + "-" + randStr(4) + "-" + randStr(4) + "-" + randStr(4)
}

func handle(route string, handler func(http.ResponseWriter, *http.Request), note string) {
	fmt.Println("Prepare route: " + route + " - " + note)
	http.HandleFunc(route, func(w http.ResponseWriter, r *http.Request) {
		fmt.Printf("Request: [%s] [%s] %s\n", r.Host, r.Method, r.URL)
		handler(w, r)
	})
}

func main() {
	flag.Parse()

	rand.Seed(time.Now().UTC().UnixNano())
	handle("/d1", DefaultHandler1, "default with string array")
	handle("/d2", DefaultHandler2, "default with object array")
	handle("/ym1_gen", YMHandler1Step1, "yandex pincode generator")
	handle("/ym1_get", YMHandler1Step2, "yandex pincode getter")
	handle("/ym1_gen_v3", YMHandler1Step1V3, "yandex pincode generator v3")
	handle("/ym1_get_v3", YMHandler1Step2V3, "yandex pincode getter v3")
	fmt.Println("Server listen at " + listen)
	http.ListenAndServe(listen, nil)
}
