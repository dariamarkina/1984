package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"

	uuid "github.com/satori/go.uuid"
)

type ymReq1 struct {
	AgentID           int      `json:"agentId"`
	Campaign          string   `json:"campaign"`
	PinType           string   `json:"pinType"`
	PinCount          int      `json:"pinCount"`
	RequestID         string   `json:"requestId"`
	Origin            string   `json:"origin"`
	PinExpirationDate string   `json:"pinExpirationDate"`
	Amount            ymAmount `json:"amount"`
	RewardType        string   `json:"rewardType"`
}

type ymAmount struct {
	Amount              int `json:"amount"`
	CurrencyNumericCode int `json:"currencyNumericCode"`
}

type ymRespV2 struct {
	Result struct {
		GeneratedPinsID string `json:"generatedPinsId"`
	} `json:"result"`

	Status string      `json:"status"`
	Errors interface{} `json:"errors"`
}

type ymReq2V2 struct {
	GeneratedPinId string `json:"generatedPinId"`
	IsTest         bool   `json:"isTest"`
	NextPageMark   int    `json:"nextPageMark"`
}

type ymPinV2 struct {
	Pin string `json:"pin"`
}

type ymResp2V2 struct {
	Result struct {
		Pins         []ymPinV2 `json:"pins"`
		NextPageMark int     `json:"nextPageMark"`
		HasMore      bool    `json:"hasMore"`
		Account      string  `json:"account"`
	} `json:"result"`

	Status string      `json:"status"`
	Errors interface{} `json:"errors"`
}

var ymCodes = make(map[string][]string)

func YMHandler1Step1(w http.ResponseWriter, r *http.Request) {
	fmt.Println("--------------------------------------------------------------")
	var req ymReq1
	body, _ := ioutil.ReadAll(r.Body)
	err := json.Unmarshal([]byte(body), &req)
	if err != nil {
		error(err.Error(), w)
		return
	}

	fmt.Printf("Request data: %+v, Content type: %v\n", req, r.Header.Get("Content-type"))

	uuidObj, _ := uuid.NewV4()
	uuid := uuidObj.String()
	fmt.Printf("Generate %d pins for new UUID: %s\n", req.PinCount, uuid)
	codes := []string{}
	for i := 0; i < req.PinCount; i++ {
		codes = append(codes, genCode())
	}
	ymCodes[uuid] = codes

	var response ymRespV2
	if errorFlag == 1 {
		response.Errors = `{"custom": {"error": ["no_codes_for_you_boy"]}}`
		response.Status = "error"
	} else {
		response.Result.GeneratedPinsID = uuid
	}

	fmt.Printf("Response data: %+v\n", response)
	jsonResponseBody, _ := json.Marshal(response)
	readerBody := bytes.NewBuffer(jsonResponseBody)
	fmt.Fprintf(w, readerBody.String())
}

func YMHandler1Step2(w http.ResponseWriter, r *http.Request) {
	fmt.Println("--------------------------------------------------------------")
	var req ymReq2V2
	var batchSize = 100
	body, _ := ioutil.ReadAll(r.Body)
	err := json.Unmarshal([]byte(body), &req)
	if err != nil {
		error(err.Error(), w)
		return
	}

	fmt.Printf("Request data: %+v, Content type: %v\n", req, r.Header.Get("Content-type"))

	if req.IsTest {
		ymCodes[req.GeneratedPinId] = []string{"test-code"}
	}

	if _, ok := ymCodes[req.GeneratedPinId]; !ok && errorFlag != 3 {
		error("No such pins: "+req.GeneratedPinId, w)
		return
	}

	var response ymResp2V2
	if errorFlag == 2  {
		response.Errors = `{"custom": {"error": ["no_codes_for_you_boy"]}}`
		response.Status = "error"
	} else {
		response.Result.HasMore = true

		for i := req.NextPageMark; i < batchSize+req.NextPageMark; i++ {
			if errorFlag == 3 { // в этом случае, отдаем 0 промокодов в ответе
				response.Result.HasMore = false
				response.Result.NextPageMark = 0
				break
			}
			if i < len(ymCodes[req.GeneratedPinId]) {
				response.Result.NextPageMark = i + 1
				response.Result.Pins = append(response.Result.Pins, ymPinV2{
					Pin: ymCodes[req.GeneratedPinId][i],
				})
			}
			if i >= len(ymCodes[req.GeneratedPinId])-1 {
				fmt.Printf("Remove %s pins\n", req.GeneratedPinId)
				response.Result.HasMore = false
				response.Result.NextPageMark = 0
				delete(ymCodes, req.GeneratedPinId)

				break
			}

		}
	}
	fmt.Printf("Response data: %+v\n", response)
	jsonResponseBody, _ := json.Marshal(response)
	readerBody := bytes.NewBuffer(jsonResponseBody)
	fmt.Fprintf(w, readerBody.String())
}