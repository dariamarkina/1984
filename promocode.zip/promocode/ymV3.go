package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"

	uuid "github.com/satori/go.uuid"
)

type ymReq1V3 struct {
	AgentID           int      `json:"agentId"`
	Campaign          string   `json:"campaign"`
	Type              string   `json:"type"`
	Count             int      `json:"count"`
	RequestID         string   `json:"requestId"`
	Origin            string   `json:"origin"`
	PinExpirationDate string   `json:"pinExpirationDate"`
	Amount            string   `json:"amount"`
	Accounts          []string `json:"accounts"`
	RewardType        string   `json:"rewardType"`
	Currency          string   `json:"currency"`
}

type ymReq2V3 struct {
	Packid string `json:"packId"`
	IsTest         bool   `json:"isTest"`
	NextPageMark   int    `json:"nextPageMark"`
}

type ymRespV3 struct {
	Result struct {
		GeneratedPinsID string `json:"packId"`
	} `json:"result"`

	Status string      `json:"status"`
	Errors interface{} `json:"errors"`
}

type ymResp2V3 struct {
	Result struct {
		Count int     `json:"count"`
		Promocodes         []ymPinV3 `json:"promocodes"`
		NextPageMark int     `json:"nextPageMark"`
		HasMore      bool    `json:"hasMore"`
		PackId      string  `json:"packId"`
	} `json:"result"`

	Status string      `json:"status"`
	Errors interface{} `json:"errors"`
}

type ymPinV3 struct {
	Value string `json:"value"`
	Account      string  `json:"account,omitempty"`
}


type ymCurrency struct {
	Currency []string `json:"currency"`
}

type ymValidateErrV3 struct {
	Validation ymCurrency`json:"validation"`
}

type ymUnknownPromocodeType struct {
	UnknownPromocodeType []string `json:"UnknownPromocodeType"`
}

type ymApplicationErrV3 struct {
	Application ymUnknownPromocodeType `json:"application"`
}


func YMHandler1Step1V3(w http.ResponseWriter, r *http.Request) {
	fmt.Println("--------------------------------------------------------------")
	var req ymReq1V3
	body, _ := ioutil.ReadAll(r.Body)
	err := json.Unmarshal(body, &req)
	if err != nil {
		error(err.Error(), w)
		return
	}

	fmt.Printf("Request data: %+v, Content type: %v\n", req, r.Header.Get("Content-type"))

	uuidObj, _ := uuid.NewV4()
	uuid := uuidObj.String()
	var count int
	switch req.Type {
	case "Unique":
		count = req.Count
	case "UniqueBinding":
		count = len(req.Accounts)
	case "Common":
		count = 1
	default:
		error(fmt.Sprintf("unexpected type: %s", req.Type), w)
		return
	}
	fmt.Printf("Generate %d pins for new UUID: %s\n", count, uuid)
	codes := []string{}
	for i := 0; i < count; i++ {
		codes = append(codes, genCode())
	}
	ymCodes[uuid] = codes

	var response ymRespV3
	if errorFlag == 1 {
		response.Errors = ymValidateErrV3{
			Validation: ymCurrency{Currency: []string{"currency should be specified if rewardType is Money"}},
		}
		response.Status = "error"
	} else {
		response.Result.GeneratedPinsID = uuid
	}
	fmt.Printf("Response data: %+v\n", response)
	jsonResponseBody, _ := json.Marshal(response)
	readerBody := bytes.NewBuffer(jsonResponseBody)
	fmt.Fprintf(w, readerBody.String())
}

func YMHandler1Step2V3(w http.ResponseWriter, r *http.Request) {
	fmt.Println("--------------------------------------------------------------")
	var req ymReq2V3
	var batchSize = 100
	body, _ := ioutil.ReadAll(r.Body)
	err := json.Unmarshal(body, &req)
	if err != nil {
		error(err.Error(), w)
		return
	}

	fmt.Printf("Request data: %+v, Content type: %v\n", req, r.Header.Get("Content-type"))

	if req.IsTest && errorFlag != 3 {
		ymCodes[req.Packid] = []string{"test-code"}
	}

	if _, ok := ymCodes[req.Packid]; !ok && errorFlag != 3 {
		error("No such pins: "+req.Packid, w)
		return
	}

	var response ymResp2V3
	if errorFlag == 2 {
		response.Errors = ymApplicationErrV3{
			Application: ymUnknownPromocodeType{UnknownPromocodeType: []string{"Неизвестный тип промокодов"}},
		}
		response.Status = "error"
	} else {
		response.Result.HasMore = true

		for i := req.NextPageMark; i < batchSize+req.NextPageMark; i++ {
			if errorFlag == 3 { // в этом случае, отдаем 0 промокодов в ответе
				response.Result.HasMore = false
				response.Result.NextPageMark = 0
				break
			}
			if i < len(ymCodes[req.Packid]) {
				response.Result.NextPageMark = i + 1
				if i % 2 == 0 {
					response.Result.Promocodes = append(response.Result.Promocodes, ymPinV3{
						Value: ymCodes[req.Packid][i],
						Account: "4546846541654",
					})
				} else {
					response.Result.Promocodes = append(response.Result.Promocodes, ymPinV3{
						Value: ymCodes[req.Packid][i],
					})
				}
			}
			if i >= len(ymCodes[req.Packid])-1 {
				fmt.Printf("Remove %s pins\n", req.Packid)
				response.Result.HasMore = false
				response.Result.NextPageMark = 0
				delete(ymCodes, req.Packid)

				break
			}

		}
	}
	fmt.Printf("Response data: %+v\n", response)
	jsonResponseBody, _ := json.Marshal(response)
	readerBody := bytes.NewBuffer(jsonResponseBody)
	fmt.Fprintf(w, readerBody.String())
}
