package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"time"
)

type defaultReq struct {
	AccountID        int                    `json:"account_id"`
	LoyaltyID        int                    `json:"loyalty_id"`
	LoyaltyName      string                 `json:"loyalty_name"`
	LoyaltyShortname string                 `json:"loyalty_shortname"`
	CampaignID       int                    `json:"campaign_id"`
	CampaignName     string                 `json:"campaign_name"`
	WorkflowID       int                    `json:"workflow_id"`
	WorkflowName     string                 `json:"workflow_name"`
	Count            int                    `json:"count"`
	IsTest           bool                   `json:"is_test"`
	Fields           map[string]interface{} `json:"fields"`
}

type defaultResp1 struct {
	Codes []string `json:"codes"`
}

type defaultResp2 struct {
	Codes []codeField `json:"codes"`
}

type codeField struct {
	Code   string                 `json:"code"`
	Fields map[string]interface{} `json:"fields"`
}

func error(errStr string, w http.ResponseWriter) {
	fmt.Println("Error:", errStr)
	w.WriteHeader(http.StatusInternalServerError)
	w.Write([]byte("500 - " + errStr))
}

func DefaultHandler1(w http.ResponseWriter, r *http.Request) {
	var req defaultReq
	body, _ := ioutil.ReadAll(r.Body)
	err := json.Unmarshal([]byte(body), &req)
	if err != nil {
		error(err.Error(), w)
		return
	}

	fmt.Printf("Request data: %+v\n", req)

	if !req.IsTest {
		delay, _ := req.Fields["delay"].(float64)
		if delay > 0 {
			fmt.Printf("Delay msec: %d\n", int(delay))
			time.Sleep(time.Millisecond * time.Duration(int(delay)))
		}
	}

	response := make(map[string]interface{})
	codes := []string{}
	for i := 0; i < req.Count; i++ {
		codes = append(codes, genCode())
	}
	response["codes"] = codes

	fmt.Printf("Response data: %+v\n", response)
	jsonResponseBody, _ := json.Marshal(response)
	readerBody := bytes.NewBuffer(jsonResponseBody)
	fmt.Fprintf(w, readerBody.String())
}

func DefaultHandler2(w http.ResponseWriter, r *http.Request) {
	var req defaultReq
	body, _ := ioutil.ReadAll(r.Body)
	err := json.Unmarshal([]byte(body), &req)
	if err != nil {
		error(err.Error(), w)
		return
	}

	if !req.IsTest {
		delay, _ := req.Fields["delay"].(float64)
		if delay > 0 {
			fmt.Printf("Delay msec: %d\n", int(delay))
			time.Sleep(time.Millisecond * time.Duration(int(delay)))
		}
	}

	fmt.Printf("Request data: %+v\n", req)

	response := defaultResp2{}

	for i := 0; i < req.Count; i++ {
		response.Codes = append(response.Codes, codeField{
			Code:   genCode(),
			Fields: req.Fields,
		})
	}

	fmt.Printf("Response data: %+v\n", response)
	jsonResponseBody, _ := json.Marshal(response)
	readerBody := bytes.NewBuffer(jsonResponseBody)
	fmt.Fprintf(w, readerBody.String())
}
